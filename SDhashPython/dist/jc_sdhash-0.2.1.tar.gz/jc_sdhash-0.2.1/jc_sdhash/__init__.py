# jc_sdhash/__init__.py
from .wrapper import generate, compare, validate

__version__ = "0.2.1"  # Optional: Add version info